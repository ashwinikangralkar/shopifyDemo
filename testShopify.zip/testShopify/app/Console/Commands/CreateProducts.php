<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use GuzzleHttp\Client;

use App\Models\Product;


class CreateProducts extends Command
{
    protected $signature = 'products:create';
    protected $description = 'Sync products with variants and options';

    public function handle()
    {
        //get product and variant details
        // products with variants
        $products = Product::with('variants')->get();
        foreach ($products as $value) {
          foreach ($value->variants as $variant) {
                    $this->syncProductWithShopify($value, $variant);
          }
        }

          // Sync products without variants
        $productsWithoutVariants = Product::whereDoesntHave('variants')->get();
        foreach ($productsWithoutVariants as $product) {
            $this->syncProductWithShopify($product);
        }
}

 // function to sync
    protected function syncProductWithShopify($product, $variant = null)
    {

        // Shopify API credentials
      $shopifyStoreUrl = 'https://43439e-0a.myshopify.com';
      $apiKey = '76fe29188dd731038c4b652df5f1a94d';
      $password = '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';
      $apiVersion = '2024-04';

        // Initialize cURL session for Shopify API
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      curl_setopt($ch, CURLOPT_URL, "$shopifyStoreUrl/admin/api/$apiVersion/products.json");
      curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$password");

      // search if product already exists
      $searchUrl = "$shopifyStoreUrl/admin/api/$apiVersion/products.json?title=" . urlencode($product->title);
      curl_setopt($ch, CURLOPT_URL, $searchUrl);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

      // Execute the cURL request to search for the product
      $response = curl_exec($ch);

      // Check for errors
    if ($response === false) {
        $error = curl_error($ch);
        var_dump($error); // Log or handle the error...
    } else {
      // Decode the JSON response
      $responseData = json_decode($response, true);
      // Check if the product exists
        if (!empty($responseData['products'])) {
            // Product exists, so update it
            $shopifyProductId = $responseData['products'][0]['id'];
            curl_setopt($ch, CURLOPT_URL, "$shopifyStoreUrl/admin/api/$apiVersion/products/$shopifyProductId.json");
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        } else {
            // Product doesn't exist, so create it
            curl_setopt($ch, CURLOPT_URL, "$shopifyStoreUrl/admin/api/$apiVersion/products.json");
            curl_setopt($ch, CURLOPT_POST, true);
        }

    }

      if(!empty($variant)){
        $productData = [
        'product' => [
            "title" => $product->title,
            "body_html" => "<strong>".$product->description."</strong>",
            "vendor" => $product->vendor,
            "product_type" => $product->product_type,
            'variants' => [
                [
                    "title" => "t1",
                    "price" => $variant->price,
                    "sku" => $variant->sku,
                ],
            ],
            'options' => [
                [
                    "name" => "Size",
                    "values" => ["Small", "Medium", "Large"],
                ]
            ]
        ]
      ];
      }else{
        $productData = [
        'product' => [
            "title" => $product->title,
            "body_html" => "<strong>".$product->description."</strong>",
            "vendor" => $product->vendor,
            "product_type" => $product->product_type,
        ]
      ];
      }

      // Convert product data to JSON
        $productDataJson = json_encode($productData);
        // Set product data in request body
        curl_setopt($ch, CURLOPT_POSTFIELDS, $productDataJson);
        echo "Request Data: " . $productDataJson . PHP_EOL;

        // Execute the cURL request to update or create the product
        $response = curl_exec($ch);

        // Check for errors
        if ($response === false) {
            $error = curl_error($ch);
            var_dump($error); // Log or handle the error...
        } else {
            // Decode the JSON response
            $responseData = json_decode($response, true);
            echo "Response: " . $response . PHP_EOL;
            // Handle the response and update or insert the Shopify product ID into your database
            if (isset($responseData['product']['id'])) {
                $shopifyProductId = $responseData['product']['id'];
                $product->shopify_id = $shopifyProductId;
                $product->save();
            }
        }





    }
}
